#WaveToMp3 Converter
A simple Windows Forms App (C#), that converts a wave file to mp3 using the lame encoder engine.
The gui is based on the user interface example at: http://lame.sourceforge.net/lame_ui_example.php

